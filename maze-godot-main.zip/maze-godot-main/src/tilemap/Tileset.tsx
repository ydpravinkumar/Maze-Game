<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tileset" tilewidth="32" tileheight="32" tilecount="1767" columns="31">
 <image source="../game/Assets/tileset.png" width="992" height="1824"/>
 <tile id="434">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="4" width="29" height="28"/>
  </objectgroup>
 </tile>
 <tile id="435">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="2" width="32" height="30"/>
  </objectgroup>
 </tile>
 <tile id="436">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="2" width="32" height="30"/>
  </objectgroup>
 </tile>
 <tile id="437">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="4" width="29" height="28"/>
  </objectgroup>
 </tile>
 <tile id="465">
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="0" width="30" height="32"/>
  </objectgroup>
 </tile>
 <tile id="468">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="29.75" height="32"/>
  </objectgroup>
 </tile>
 <tile id="496">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="0" width="31" height="32"/>
  </objectgroup>
 </tile>
 <tile id="499">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="31" height="32"/>
  </objectgroup>
 </tile>
 <tile id="527">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="0" width="29" height="32"/>
  </objectgroup>
 </tile>
 <tile id="558">
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="0" width="30" height="32"/>
  </objectgroup>
 </tile>
 <tile id="559">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="560">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="561">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="30" height="32"/>
  </objectgroup>
 </tile>
 <tile id="589">
  <objectgroup draworder="index" id="2">
   <object id="4" x="3" y="0" width="29" height="29.25"/>
  </objectgroup>
 </tile>
 <tile id="590">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.25" y="0" width="32" height="29.25"/>
  </objectgroup>
 </tile>
 <tile id="591">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="27.75"/>
  </objectgroup>
 </tile>
 <tile id="592">
  <objectgroup draworder="index" id="3">
   <object id="4" x="0" y="0" width="28" height="29"/>
  </objectgroup>
 </tile>
 <tile id="1034">
  <objectgroup draworder="index" id="2">
   <object id="1" x="27" y="22" width="5" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1035">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="21" width="16" height="11"/>
  </objectgroup>
 </tile>
 <tile id="1036">
  <objectgroup draworder="index" id="2">
   <object id="1" x="27" y="22" width="5" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1037">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="21" width="15" height="11"/>
  </objectgroup>
 </tile>
 <tile id="1041">
  <objectgroup draworder="index" id="2">
   <object id="1" x="15.5" y="0" width="16.5" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1042">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="11" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1059">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4" y="15" width="24" height="17"/>
  </objectgroup>
 </tile>
 <tile id="1065">
  <objectgroup draworder="index" id="2">
   <object id="1" x="17.25" y="0" width="14.75" height="28"/>
  </objectgroup>
 </tile>
 <tile id="1066">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="25.25" height="25"/>
  </objectgroup>
 </tile>
 <tile id="1067">
  <objectgroup draworder="index" id="2">
   <object id="1" x="15.5" y="0" width="16.5" height="27"/>
  </objectgroup>
 </tile>
 <tile id="1068">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="25.75" height="25.5"/>
  </objectgroup>
 </tile>
 <tile id="1069">
  <objectgroup draworder="index" id="2">
   <object id="1" x="18.75" y="0" width="13.25" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1070">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="21" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1072">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="29.5"/>
  </objectgroup>
 </tile>
 <tile id="1073">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="20.75" height="26.25"/>
  </objectgroup>
 </tile>
 <tile id="1088">
  <objectgroup draworder="index" id="2">
   <object id="1" x="7" y="0" width="25" height="28"/>
  </objectgroup>
 </tile>
 <tile id="1090">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="31" height="31"/>
  </objectgroup>
 </tile>
 <tile id="1100">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="9"/>
  </objectgroup>
 </tile>
 <tile id="1101">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="31" height="6.75"/>
  </objectgroup>
 </tile>
 <tile id="1154">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1157">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1160">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1178">
  <objectgroup draworder="index" id="2">
   <object id="1" x="17" y="19" width="15" height="13"/>
  </objectgroup>
 </tile>
 <tile id="1179">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="17" width="25" height="15"/>
  </objectgroup>
 </tile>
 <tile id="1180">
  <objectgroup draworder="index" id="2">
   <object id="1" x="5" y="23" width="23" height="9"/>
  </objectgroup>
 </tile>
 <tile id="1185">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="29"/>
  </objectgroup>
 </tile>
 <tile id="1188">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="27.75"/>
  </objectgroup>
 </tile>
 <tile id="1191">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="26.75"/>
  </objectgroup>
 </tile>
 <tile id="1196">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1199">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
   <object id="2" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1202">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1209">
  <objectgroup draworder="index" id="2">
   <object id="1" x="5" y="0" width="27" height="29.75"/>
  </objectgroup>
 </tile>
 <tile id="1210">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="28.5" height="30.75"/>
  </objectgroup>
 </tile>
 <tile id="1211">
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="0" width="27.25" height="28.25"/>
  </objectgroup>
 </tile>
 <tile id="1212">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4" y="8" width="22" height="24"/>
  </objectgroup>
 </tile>
 <tile id="1227">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="30.5" height="25"/>
  </objectgroup>
 </tile>
 <tile id="1230">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="23"/>
  </objectgroup>
 </tile>
 <tile id="1233">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="19.25"/>
  </objectgroup>
 </tile>
 <tile id="1243">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="0" width="31" height="26.5"/>
  </objectgroup>
 </tile>
 <tile id="1271">
  <objectgroup draworder="index" id="2">
   <object id="1" x="11" y="0" width="21" height="27"/>
  </objectgroup>
 </tile>
 <tile id="1272">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="26.75" height="27"/>
  </objectgroup>
 </tile>
 <tile id="1275">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="1" width="27.75" height="31"/>
  </objectgroup>
 </tile>
 <wangsets>
  <wangset name="RockRight" type="mixed" tile="468">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="-1" probability="1"/>
   <wangtile tileid="468" wangid="1,1,1,1,1,2,2,2"/>
   <wangtile tileid="499" wangid="1,1,1,1,1,2,2,2"/>
  </wangset>
  <wangset name="RockLeft" type="mixed" tile="465">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="-1" probability="1"/>
   <wangtile tileid="465" wangid="1,2,2,2,1,1,1,1"/>
   <wangtile tileid="496" wangid="1,2,2,2,1,1,1,1"/>
  </wangset>
 </wangsets>
</tileset>
