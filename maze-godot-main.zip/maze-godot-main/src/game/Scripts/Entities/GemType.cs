namespace Maze.Scripts.Entities;

public enum GemType
{
	Diamond,
	Gold
}
