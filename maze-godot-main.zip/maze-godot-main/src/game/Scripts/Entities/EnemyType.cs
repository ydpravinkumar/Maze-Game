﻿namespace Maze.Scripts.Entities;

public enum EnemyType
{
    Red,
    Yellow,
}
