﻿namespace Maze.Scripts.Pathfinding;

public enum PathfindingAlgorithmType
{
    AStar,
    Dijkstra,
    Bfs
}
