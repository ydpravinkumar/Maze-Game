﻿namespace Maze.Scripts.Pathfinding;

public enum Alignment
{
    TopLeft,
    Center
}
